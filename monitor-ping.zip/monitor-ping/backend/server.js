
const express = require('express');
const cors = require('cors');
const ping = require('ping');

const app = express();
app.use(cors());
app.use(express.json());

app.post('/ping', async (req, res) => {
  const { devices } = req.body;
  if (!devices || !Array.isArray(devices)) {
    return res.status(400).json({ error: 'Invalid devices list' });
  }

  const results = await Promise.all(
    devices.map(async (ip) => {
      const result = await ping.promise.probe(ip);
      return { ip, alive: result.alive };
    })
  );

  res.json(results);
});

app.listen(3001, () => {
  console.log('Backend listening on port 3001');
});
