
import React, { useState } from 'react';
import axios from 'axios';

const App = () => {
  const [devices, setDevices] = useState(['192.168.1.1']);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleChange = (index, value) => {
    const updated = [...devices];
    updated[index] = value;
    setDevices(updated);
  };

  const addDevice = () => {
    setDevices([...devices, '']);
  };

  const checkDevices = async () => {
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:3001/ping', { devices });
      setResults(res.data);
    } catch (err) {
      alert('Error al hacer ping');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-2xl font-bold mb-4">Monitor de Dispositivos</h1>
      {devices.map((ip, index) => (
        <input
          key={index}
          value={ip}
          onChange={(e) => handleChange(index, e.target.value)}
          placeholder="IP del dispositivo"
          className="block mb-2 p-2 border rounded w-full max-w-md"
        />
      ))}
      <button
        onClick={addDevice}
        className="bg-blue-500 text-white px-4 py-2 rounded mr-2"
      >
        Agregar IP
      </button>
      <button
        onClick={checkDevices}
        className="bg-green-500 text-white px-4 py-2 rounded"
      >
        {loading ? 'Verificando...' : 'Hacer Ping'}
      </button>

      <div className="mt-6 grid gap-4 grid-cols-1 md:grid-cols-2">
        {results.map((device, index) => (
          <div
            key={index}
            className={`p-4 rounded shadow ${
              device.alive ? 'bg-green-100' : 'bg-red-100'
            }`}
          >
            <h2 className="font-semibold">{device.ip}</h2>
            <p>{device.alive ? '🟢 Activo' : '🔴 Inactivo'}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
